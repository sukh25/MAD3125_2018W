package com.example.navneet.sgnparking;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Call extends AppCompatActivity implements View.OnClickListener {


    Button call1;
    Button call2;
    Button call3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);
        call1 = (Button) findViewById(R.id.call1);
        call2 = (Button) findViewById(R.id.call2);
        call3 = (Button) findViewById(R.id.call3);
        call1.setOnClickListener(this);
        call2.setOnClickListener(this);
        call3.setOnClickListener(this);
    }

    private void makeCall1(){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:6479149136"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(getApplicationContext(),
                    "Call permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(callIntent);
    }
    private void makeCall2(){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:4752774773"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(getApplicationContext(),
                    "Call permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(callIntent);
    }
    private void makeCall3(){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:4379893362"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(getApplicationContext(),
                    "Call permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(callIntent);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.call1:
                makeCall1();
                break;
            case R.id.call2:
                makeCall2();
                break;
            case R.id.call3:
                makeCall3();
                break;
        }

    }
}
