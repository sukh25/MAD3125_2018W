package com.example.navneet.sgnparking;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ParkingReport extends AppCompatActivity {


    ListView report;

    DBHelper sqlitehelper;
    SQLiteDatabase SGNParking;
    ListAdapter listAdapter;
    Cursor cursor;
    ArrayList<String> location;
    ArrayList<String> price;
    ArrayList<String> time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_report);
        report = (ListView) findViewById(R.id.reportView);
        location = new ArrayList<String>();
        price = new ArrayList<String>();
        time = new ArrayList<String>();
        sqlitehelper = new DBHelper(this);
    }

    @Override
    protected void onResume() {
        ShowSQLiteDBdata();
        super.onResume();
    }

    private void ShowSQLiteDBdata() {

        SGNParking = sqlitehelper.getWritableDatabase();
        cursor = SGNParking.rawQuery("SELECT * FROM "+sqlitehelper.Parking_Table+"", null);
        location.clear();
        price.clear();
        time.clear();
        if (cursor.moveToFirst()) {
            do {
                location.add(cursor.getString(cursor.getColumnIndex("Location")));
                price.add(cursor.getString(cursor.getColumnIndex("Price")));
                time.add(cursor.getString(cursor.getColumnIndex("Time")));
            } while (cursor.moveToNext());
        }
        listAdapter = new ReportAdapter(ParkingReport.this,location,price,time);
        report.setAdapter(listAdapter);
        cursor.close();
    }
}
