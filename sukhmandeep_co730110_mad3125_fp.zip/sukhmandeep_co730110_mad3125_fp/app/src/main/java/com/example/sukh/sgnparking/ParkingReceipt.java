package com.example.navneet.sgnparking;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AdapterView;
import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class ParkingReceipt extends AppCompatActivity implements OnItemSelectedListener, View.OnClickListener {



    TextView CarNumber;
    TextView EnterTime;
    Button ProceedPay;
    String item;
   float price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_receipt);
        Spinner spinner = (Spinner) findViewById(R.id.CarSpinner);
        spinner.setOnItemSelectedListener(this);
        List<String> categories = new ArrayList<String>();
        categories.add("Audi");
        categories.add("Acura");
        categories.add("BMW");
        categories.add("Bugati");
        categories.add("Bentley");
        categories.add("Cadilac");
        categories.add("Chevorlet");
        categories.add("Dodge");
        categories.add("Ford");
        categories.add("Ferrari");
        
       ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        CarNumber = (TextView) findViewById(R.id.CarNumber);
        EnterTime = (EditText) findViewById(R.id.EnterTime);
        ProceedPay = (Button) findViewById(R.id.ProceedToPay);
        ProceedPay.setOnClickListener(this);
        SharedPreferences sp = getSharedPreferences("com.example.navneet.sgnparking", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        String data = sp.getString("carnumber","ON-9823");
        CarNumber.setText(data);


    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
         item = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item

    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onClick(View view) {


        if(view.getId() == ProceedPay.getId()) {

            SharedPreferences sp = getSharedPreferences("com.example.navneet.sgnparking", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();
            price = 5 * Float.parseFloat(EnterTime.getText().toString());
            edit.putString("carname",item);
            edit.putFloat("price",price);
            edit.putString("Time",EnterTime.getText().toString());
            edit.commit();
            Intent pay = new Intent(this,FinalPay.class);
            startActivity(pay);
            }
}}
